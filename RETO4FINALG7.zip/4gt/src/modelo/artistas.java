package modelo;

public class artistas {
	String IDArtista, nombre, descripcion, img;

	public String getIDArtista() {
		return IDArtista;
	}

	public void setIDArtista(String iDArtista) {
		IDArtista = iDArtista;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}
	
	
	
}