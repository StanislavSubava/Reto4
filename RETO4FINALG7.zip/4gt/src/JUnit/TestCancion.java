package JUnit;



import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import modelo.Cancion;

public class TestCancion {

	@Test
	void testarcancionConstructor() {
		Cancion cancion = new Cancion();
		assertNull(cancion.getId());
		assertNull(cancion.getNombre());
		assertNull(cancion.getDuracion());
		assertNull(cancion.getTipo());

	}
	
	@Test
	void testGetterAndSetter() {
		Cancion cancion = new Cancion();
		
		cancion.setId(0);
		assertNull(cancion.getId());
		
		cancion.setNombre("");
		assertNull(cancion.getNombre());
		
		cancion.setDuracion(0);
		assertNull(cancion.getDuracion());
		
		cancion.setTipo("");
		assertNull(cancion.getTipo());
		

	}

}
