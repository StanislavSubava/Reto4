package Controlador;

public class exportacion {

	public static String exportarRuta() {

		String Localizacion = "C:\\curso-java\\4g7.zip_expanded\\4gt\\txt";
		return Localizacion;

	}

}
